<html>
	<style>

button {
			background-color: #13A818;
			color: white;
			padding: 14px 20px;
			margin: 8px 0;
			border: none;
			cursor: pointer;
			width: 100%;
			font-size: 20px; 
		}

		/* Add a hover effect for buttons */
		button:hover {
			background-color:#06930B; 
			font-family: Helvetica;

		}
.cancelbtn {
			width: auto;
			padding: 10px 18px;
			border-radius: 10px;
			background-color: #f44336;
		}

		.container {
			padding: 16px;
		}

		</style>
<?php

	if(isset($_POST['cname'])){
		$cname=$_POST['cname'];
		$oname=$_POST['oname'];
		$date=$_POST['date'];
		$time=$_POST['time'];
		$location=$_POST['location'];

		$servername="localhost:3308";
		$username="root";
		$password="";
		$dbname="blood_management_system";

		$conn=mysqli_connect($servername,$username,$password,$dbname);

	if(!$conn){
		die("Error while connecting...");
	}
	
	$qry="insert into campaign(cam_name,org_name,cam_date,cam_time,cam_location) values ('$cname','$oname','$date','$time','$location')";
	$result=mysqli_query($conn,$qry);

	if($result){
		echo"Campaign Successfully Created";
	}
	else{
		echo"Error while inserting data";

	
	}

	}
	else{
		echo"Go back to registration page";
	}
?>
<div class="container" >
			<a href="dashboard.php"><button type="button" class="cancelbtn" >Go Back</button></a>
			<!-- <span class="psw">Forgot <a href="#">password?</a></span> -->
		  </div>
</html>