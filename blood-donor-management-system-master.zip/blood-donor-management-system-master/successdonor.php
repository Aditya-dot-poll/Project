<html>
	<style>

button {
			background-color: #13A818;
			color: white;
			padding: 14px 20px;
			margin: 8px 0;
			border: none;
			cursor: pointer;
			width: 100%;
			font-size: 20px; 
		}

		/* Add a hover effect for buttons */
		button:hover {
			background-color:#06930B; 
			font-family: Helvetica;

		}
.cancelbtn {
			width: auto;
			padding: 10px 18px;
			border-radius: 10px;
			background-color: #f44336;
		}

		.container {
			padding: 16px;
		}

		</style>
<?php
session_start(); //to start a session which store info
include 'dbconnect.php';
$username=$_POST['uname'];
$password=$_POST['psw'];

$qry="select * from user where u_name='$username' && u_pass='$password' "; //select the uname and pass value from the database and check
$result=mysqli_query($conn,$qry);
$count=mysqli_num_rows($result);
if($count>0){
	echo "Successfully logged in";
	$_SESSION['key']=$username; //'key' is a varaible
	header('location:donorhome.html'); //redirect the user to the donorhime.html page after login success
}else{
	echo "Username/Password didnt match";
}

?>
<div class="container" >
			<a href="loginDonor.php"><button type="button" class="cancelbtn" >Go Back</button></a>
			<!-- <span class="psw">Forgot <a href="#">password?</a></span> -->
		  </div>
</html>